package com.houkai.bak.two;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		TankFrame TankFrame = new TankFrame();
		//在主线程每隔50毫秒刷新窗口,用repaint方法重新调用paint方法
		while (true) {
			Thread.sleep(50);
			TankFrame.repaint();
		}
	}

}
