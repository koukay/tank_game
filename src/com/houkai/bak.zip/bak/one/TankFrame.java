package com.houkai.bak.one;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TankFrame extends Frame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int x = 200, y = 200;
	Dir dir = Dir.DOWN;
	private static final int SPEED=10;
	/**
	 * 
	 */
	public TankFrame() {
		setSize(800, 600);
		setResizable(false);
		setTitle("tank war");
		setVisible(true);
		this.addKeyListener(new MyKeyListener());
		//窗口监听
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	@Override
	public void paint(Graphics g) {
		g.fillRect(x, y, 50, 50);
		switch(dir) {
		case LEFT:
			System.out.println(dir);
			x-=SPEED;
			break;
		case RIGHT:
			System.out.println(dir);
			x+=SPEED;
			break;
		case DOWN:
			y+=SPEED;
			break;
		case UP:
			System.out.println(dir);
			y-=SPEED;
			break;
		case LEFT_DOWN:
			System.out.println(dir);
			x-=SPEED;
			y+=SPEED;
			break;
		case RIGHT_UP:
			System.out.println(dir);
			x+=SPEED;
			y-=SPEED;
			break;
		case RIGHT_DOWN:
			System.out.println(dir);
			x+=SPEED;
			y+=SPEED;
			break;
		case LEFT_UP:
			System.out.println(dir);
			x-=SPEED;
			y-=SPEED;
			break;
		}
//		g.drawString("tank", x, y);
//		x += 10;
//		y += 10;
	}

	/**
	 * @author houkai
	 *键盘监听
	 */
	class MyKeyListener extends KeyAdapter{
		boolean bl=false;
		boolean bu=false;
		boolean br=false;
		boolean bd=false;
		boolean b_r_u=false;
		boolean b_r_d=false;
		boolean b_l_u=false;
		boolean b_l_d=false;
		/* 
		*根据箭头的按键状态判断方向
		 */
		@Override
		public void keyPressed(KeyEvent e) {
			int key =e.getKeyCode();
			System.out.println(key);
			switch (key) {
			case KeyEvent.VK_LEFT:
				bl=true;
				break;
			case KeyEvent.VK_UP:
				bu=true;
				break;
			case KeyEvent.VK_RIGHT:
				br=true;
				break;
			case KeyEvent.VK_DOWN:
				bd=true;
				break;
			case KeyEvent.VK_NUMPAD9:
				b_r_u=true;
				break;
			case KeyEvent.VK_NUMPAD3:
				b_r_d=true;
				break;
			case KeyEvent.VK_NUMPAD7:
				b_l_u=true;
				break;
			case KeyEvent.VK_NUMPAD1:
				b_l_d=true;
				break;

			default:
				break;
			}
			setMainTankDir();
		}

		@Override
		public void keyReleased(KeyEvent e) {
			int key =e.getKeyCode();
			switch (key) {
			case KeyEvent.VK_LEFT:
				bl=false;
				break;
			case KeyEvent.VK_UP:
				bu=false;
				break;
			case KeyEvent.VK_RIGHT:
				br=false;
				break;
			case KeyEvent.VK_DOWN:
				bd=false;
				break;
			case KeyEvent.VK_NUMPAD9:
				b_r_u=false;
				break;
			case KeyEvent.VK_NUMPAD3:
				b_r_d=false;
				break;
			case KeyEvent.VK_NUMPAD7:
				b_l_u=false;
				break;
			case KeyEvent.VK_NUMPAD1:
				b_l_d=false;
				break;

			default:
				break;
			}
			setMainTankDir();
		}

		private void setMainTankDir() {
			if(bl) dir = Dir.LEFT;
			if(bu) dir = Dir.UP;
			if(br) dir = Dir.RIGHT;
			if(bd) dir = Dir.DOWN;
			if(b_r_u) dir = Dir.RIGHT_UP;
			if(b_r_d) dir = Dir.RIGHT_DOWN;
			if(b_l_u) dir = Dir.LEFT_UP;
			if(b_l_d) dir = Dir.LEFT_DOWN;
			System.out.println(dir);
			
		}
	}
}










