package com.houkai.bak.one;

public enum Dir {
	LEFT,UP,RIGHT,DOWN, LEFT_DOWN, RIGHT_UP, RIGHT_DOWN, LEFT_UP
}
